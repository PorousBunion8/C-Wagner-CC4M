using System;
public interface ICafe{
  string Descricao();
  double Custo();
  
}