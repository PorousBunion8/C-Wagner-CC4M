using System;

namespace PolymorphismSample{
  public abstract class Animal{
    public abstract string makeSound();
  }

  
}