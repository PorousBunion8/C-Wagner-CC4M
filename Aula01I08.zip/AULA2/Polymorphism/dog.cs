namespace PolymorphismSample{
  public class Dog : Animal{
    public override string makeSound(){
      return "au au au";
    }
  }
}