namespace PolymorphismSample{
  public class Cat : Animal{
    public override string makeSound(){
      return "Miauuuu";
    }
  }
}