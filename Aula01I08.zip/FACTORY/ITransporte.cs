public interface ITransporte{
  
  public void Entregar();
  
}