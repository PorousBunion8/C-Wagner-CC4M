using System;
using System.Collections.Generic;

public class Monitor : IObserver{
  public void Update(float temperature){
    Console.WriteLine("Temperatura atual: " + temperature);
  }
}