using System;
using System.Collections.Generic;

public interface IObserver
{
    void Update(float temperature);
}
